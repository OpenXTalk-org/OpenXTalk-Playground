jQuery(document).ready(function ($){
		$( ".sh_trigger" ).click(function(event) {
			var trigger_number = parseInt($(event.target).parent().parent().attr('class').match(/[0-9]+/)[0], 10);
			//console.log(trigger_number);
			
			$( "#sh_content_" + trigger_number).slideToggle();
			
		});
		
	
	
	
	  $(".mailchimp-subscribe").click(function(e) {
		  // get form id dynamically, avoids conflicts or lack of portability - A
		  var tFormID = $(this).closest("form").attr('id');
		  var tFormData = new Array();
		  var tValid = 1;
		  // console.log("Subscribe form submitted: " + tFormID);
		  $("form#" + tFormID + " :input").each(function(){
			  tFormData[$(this).attr('name')] = $(this).val();
			  
			  if($(this).attr('name') == "FNAME"){
				  console.log("name->" + $(this).attr('name'));
				  if(!validateName($(this).val()) || $(this).val() == 'Firstname'){
					  tValid = 0;
					  $(this).addClass("invalid");
					  $('span#'+$(this).attr('id')+'-help').text("Please tell us what is your Firstname");
					  console.log('firstname error');
				  } else {
					  $('span#'+$(this).attr('id')+'-help').text("");
				  }
			  }
			  
			  if($(this).attr('name') == "EMAIL"){
				  console.log("email->" + $(this).attr('name'));
				  if(!validateEmail($(this).val())){
					  tValid = 0;
					  $(this).addClass("invalid");
					  $('span#'+$(this).attr('id')+'-help').text("Please check your email address is valid");
					  console.log('email error');
				  } else {
					  $('span#'+$(this).attr('id')+'-help').text("");
				  }
			  }
		  });
		  
		  
		  if(tValid == 0) return;
		  console.log(tFormData);
		  $.ajax({
			  type: 'POST',
			  url: ajaxurl,
			  data: "action=email_exists&email=" + tFormData['EMAIL'],
			  success: function(data) {
				  if (data == 1) {
					  // $(".mailchimpThanks").fadeIn(400);
					  // $("form.mailchimp").fadeOut(400);
					  // document.location.href= tFormData['CONFIRM_URL'];
					  // user has clicked and wants to subscribe and download	
					  
					  var tPostData = '';
					  for(var tKey in tFormData) {
						  tPostData += "&"+tKey+"="+tFormData[tKey];
					  };
					  tPostData = "action=list_subscribe" + tPostData;
					  
					  $.ajax({
						  type: 'POST',
						  url: ajaxurl,
						  data: tPostData,
						  success: function(data) {
							 var d = new Date();
							 d.setTime(d.getTime() + (365*24*60*60*1000));
							 var expires = d.toUTCString();
							document.cookie="livecode-in="+Math.round(new Date().getTime()/1000)+"; expires="+expires+"; path=/";
							document.location.href= tFormData['CONFIRM_URL'];
							ga('send', 'event', 'home', 'Account Created', '');
						  }
					  });
					  
				  } else {
					  jQuery('#mce-EMAIL-help').addClass("invalid");
					  jQuery('span#mce-EMAIL-help').addClass("invalid");
					  jQuery('span#mce-EMAIL-help').html('This email is already associated with a LiveCode account, log in <a href="/login">here</a> instead');
				  }
			  }
			  });
	  });
	  
	  $(".form_input_replace").focus(function(e) {
		  if($(this).val() == $(this).attr("default_value")){
			  $(this).val('');
			  $(this).removeClass("placeholder");
		  }
	  });
	  
	  
	  $(".form_input_replace").focusout(function(e) {
		  if($(this).val() == ""){
			  $(this).val($(this).attr("default_value"));
			  $(this).addClass("placeholder");
			  $(this).removeClass("invalid");
			  $(this).removeClass("valid");
		  }
	  });
	  
	  $(".form_input_replace").keyup(function(e) {
		  switch($(this).attr("validate")){
			  case "email":
				  if(validateEmail($(this).val())){
					  $(this).addClass("valid");
					  $(this).removeClass("invalid");
				  } else {
					  $(this).addClass("invalid");
					  $(this).removeClass("valid");
				  }
				  break;	
			  case "name":
				  if(validateName($(this).val())){
					  $(this).addClass("valid");
					  $(this).removeClass("invalid");
				  } else {
					  $(this).addClass("invalid");
					  $(this).removeClass("valid");
				  }
				  break;
		  }
		  
	  });
	  
	  $('.livecode-tabs .livecode-tab-links a').on('click', function(e)  {
                var currentAttrValue = $(this).attr('href');
                $('.livecode-tabs ' + currentAttrValue).show().siblings().hide();
                $(this).parent('li').addClass('current').siblings().removeClass('current');
                e.preventDefault();
          });

	  /*$(".manual_login_purchase").on('click', function(e) {
		confirm("Are you sure?! YOu are logged in as Admin, it means these products will be added for free in the user's account");
	  });*/

	  $('.btn-social').on('click', function(e) {
		/* check bootstrap-social.css for more spinner classes */
		$(this).children('i').removeClass($(this).children('i').attr('class')).addClass('spinner spinner-puff');
	  });
	  
	  $(".cwd-fwd-pledge").click(function(e) {
		  // get form id dynamically, avoids conflicts or lack of portability - A
		  var tFormID = $(this).closest("form").attr('id');
		  var tFormData = new Array();
		  var tValid = 1;
		  var allhtml = $('div#cwd_fnd_container');
		  var backerssectionhtml = $('div#1430390273-1-97');
		  var pledgetotalhtml = $('h1.total-pledged-area');
		  var nbbackershtml = $('span.nb-backers-value');
		  var percentagebackershtml = $('span.percentage-backers-value');
		  var choice = $('input[type="radio"]:checked').val();
		  // console.log("Subscribe form submitted: " + tFormID);
		  $("form#" + tFormID + " :input").each(function(){
			  tFormData[$(this).attr('name')] = $(this).val();
			  
			  if($(this).attr('name') == "NAME"){
				  // console.log("name->" + $(this).attr('name'));
				  if(!validateName($(this).val()) || $(this).val() == 'Name'){
					  tValid = 0;
					  $(this).addClass("invalid");
					  $('span#'+$(this).attr('id')+'-help').text("Please tell us what is your Name");
					  console.log('name error');
				  } else {
					  $('span#'+$(this).attr('id')+'-help').text("");
				  }
			  }
			  
			  if($(this).attr('name') == "EMAIL"){
				  // console.log("email->" + $(this).attr('name'));
				  if(!validateEmail($(this).val())){
					  tValid = 0;
					  $(this).addClass("invalid");
					  $('span#'+$(this).attr('id')+'-help').text("Please check your email address is valid");
					  console.log('email error');
				  } else {
					  $('span#'+$(this).attr('id')+'-help').text("");
				  }
			  }
			  
			  if($(this).attr('name') == "TOTAL"){
				  // console.log("email->" + $(this).attr('name'));
				  if(isNaN($(this).val()) == true || $(this).val() == "" || $(this).val() < 1){
					  tValid = 0;
					  $(this).addClass("invalid");
					  $('span#'+$(this).attr('id')+'-help').text("Please enter a valid amount");
					  console.log('amount error');
				  } else {
					  $('span#'+$(this).attr('id')+'-help').text("");
				  }
			  }
		  });
		  
		  
		if(tValid == 0) {
			return;
		} else { // data is ready to be sent
			console.log(tFormData);
			var tPostData = '';
			for(var tKey in tFormData) {
				tPostData += "&"+tKey+"="+tFormData[tKey];
			};
			tPostData = "action=cwd_fnd_add" + tPostData + "&choice=" + choice;
			if (confirm("Please confirm your pledge")) {
				$.ajax({
					type: 'POST',
					url: ajaxurl,
					data: tPostData,
					success: function(data) {
						$(allhtml).html(data); // sets the tank you message
						$(backerssectionhtml).fadeOut(800);
						$(pledgetotalhtml).fadeOut(800);
						$(nbbackershtml).fadeOut(800);
						$(percentagebackershtml).fadeOut(800);
						tSend = "action=refreshAreas";
						$.ajax({
							type: 'POST',
							url: ajaxurl,
							data: tSend,
							dataType: 'json',
							success: function(d) {
								console.log(d);
								$(backerssectionhtml).html(d.list_backers).fadeIn(400);
								$(pledgetotalhtml).html(d.total_pledged).fadeIn(400);
								$(nbbackershtml).html(d.nb_backers).fadeIn(400);
								$(percentagebackershtml).html(d.percentage_pledged).fadeIn(400);
								$('div.progress-bar').width(d.percentage_pledged+'%');
							}
						});
						//alert("data sent");
					}
				});
			}
		}
	  });

	  if ($('#systemLiveCodeDownloadLink').length > 0) {
		returnsSystemLivecodeDownloadLink();
	  }
	  
	  // does not allow non numerical input
	  $('input#TOTAL').keyup(function () { 
		  this.value = this.value.replace(/[^0-9.]/g,'');
	  });
	  
	  // activate bootstrap tooltips
	  $(function () {
		  $("[rel='tooltip']").tooltip({
			placement: function(tip, element) { //$this is implicit
        			var position = $(element).position();
        			if (position.left > 515) {
            				return "left";
        			}
        			if (position.left < 515) {
            				return "right";
        			}
        			if (position.top < 110){
            				return "bottom";
        			}
        			return "top";
    			},

		  });
	  });

	$("a.sfwd-try").on("click", function() {
                console.log("try clicked");
		$(this).attr('href', function() {
			paramOpe = (($(this).attr('href').indexOf('?') == -1) ? '?' : '&');
        		return this.href + paramOpe + 'try';
    		});
        });

	  
});

function validateEmail(emailAddress) {
      var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
      return pattern.test(emailAddress);
};

function validateName(tName) {
    if( tName.length >= 1) {
      return true;
    } else {
      return false;
    }
}

function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
        vars[key] = value;
    });
    return vars;
}

// mailchimp Goal Tracking

function mailchimpGoalTracking() {
	var $mcGoal = {'settings':{'uuid':'8404b344b09103bf489dd8a9a','dc':'us7'}};
	(function() {
		var sp = document.createElement('script'); sp.type = 'text/javascript'; sp.async = true; sp.defer = true;
		sp.src = ('https:' == document.location.protocol ? 'https://s3.amazonaws.com/downloads.mailchimp.com' : 'http://downloads.mailchimp.com') + '/js/goal.min.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(sp, s);
	})();
}
mailchimpGoalTracking();

function returnsSystemLivecodeDownloadLink() {
        var OSName = "Unknown OS";
        var link = "https://livecode.com/links/livecode/get-livecode-community-placeholder";
        if (navigator.appVersion.indexOf("Win")   != -1) OSName = "windows";
        if (navigator.appVersion.indexOf("Mac")   != -1) OSName = "mac";
        if (navigator.appVersion.indexOf("X11")   != -1) OSName = "linux";
        if (navigator.appVersion.indexOf("Linux") != -1) OSName = "linux";
	if (navigator.appVersion.indexOf("Linux x86_64") != -1) OSName = "linux-86_64";
        link = link.replace("placeholder", OSName);
       	if (jQuery('#systemLiveCodeDownloadLink').length > 0) {
                jQuery('#systemLiveCodeDownloadLink').attr("href",link);
        }
        // console.log(link);
}
