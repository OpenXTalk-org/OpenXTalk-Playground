function get_time() {
    var date = new Date();
    return date.getTime();
}

jQuery(document).ready(function() {
    jQuery(document).on("click", ".btn-install", function(e) {
        if (typeof liveCode !== 'undefined') {
            liveCode.installExtension(jQuery(this).attr('path'), jQuery(this).attr('code'), jQuery(this).attr('exttype'));
        }
    });

    jQuery(document).on("click", ".btn-buy", function(e) {
        if (typeof liveCode !== 'undefined') {
            alert("To purchase this extension, please launch the store in a new browser window.");
            e.preventDefault();
        }
    });
});
