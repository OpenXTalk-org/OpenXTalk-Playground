jQuery(document).ready(function() {
    if (typeof Tawk_API !== 'undefined') {
        Tawk_API.onLoad = function() {
            Tawk_API.hideWidget();
        }
    }
});