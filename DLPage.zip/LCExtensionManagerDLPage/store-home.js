jQuery(document).ready(function(){ 	
	
	jQuery(".triggeritem").tooltip({
		effect: "slide", 
		relative: "true",
		position: "bottom right",
		offset: [-50,10]
	});
						   
	var path = "/wp-content/plugins/livecode_store/runrevstore/";
	
	jQuery.listen("click", ".basket_add", function(){
		if (jQuery('#html5').length) {
			jQuery('#html5').hide();
		}
		if (jQuery(this).attr("donation")) {
			//alert('that is a donation');
			var donation = jQuery(this).attr("donation");
			jQuery.ajax({
                        	type: "GET",
                                url: path+"jquery-functions.php?f=addDonation&t="+t+"&value="+donation,
                                success: function(data){
					// alert('donation session var added');					
                                }
                       	});
		}
		var id = jQuery(this).attr("id"); 
		var quanitity = jQuery(this).attr("quantity"); 
		var t = new  Date().getTime(); 
		jQuery.ajax({ 
			type: "GET", 
			url: path+"jquery-functions.php?f=basketAddID&t="+t, 
			data: "id="+id+"&quantity="+quanitity+"&google_analytics_client_id="+google_client_id, 
			success: function(data){  
				var data_return = data.split("|"); 
				if(data_return[0].trim() == "1"){ 
					jQuery.ajax({ 
						type: "GET", 
						url: path+"jquery-functions.php?f=basketSidebar&t="+t, 
						success: function(data){
							jQuery('#basket').show();
							jQuery("#store2010-basket").html(data);
							jQuery("html, body").animate({ scrollTop: 0 }, "slow", "swing", function(){
								jQuery("#store2010-basket a").fadeOut(100).fadeIn(200);
								//jQuery("#store2010-basket a").animate({backgroundColor: "#FFFFFF","slow","swing"});
								//jQuery("#store2010-basket a").animate({backgroundColor: "#F7714F","slow","swing"});
							});
						}
					});					 	 	
				}
			}
		});
	});

	 jQuery.listen("click", ".basket_add_donate", function(){
                var id = jQuery(this).attr("id");
                var quanitity = jQuery(this).attr("quantity");
		var amount = jQuery(this).attr("amount");
                var t = new  Date().getTime();
                jQuery.ajax({
                        type: "GET",
                        url: path+"jquery-functions.php?f=basketAddIDDonate&t="+t,
                        data: "id="+id+"&quantity="+quanitity+"&amount="+amount,
                        success: function(data){
                                var data_return = data.split("|");
                                if(data_return[0].trim() == "1"){
                                        jQuery.ajax({
                                                type: "GET",
                                                url: path+"jquery-functions.php?f=basketSidebar&t="+t,
                                                success: function(data){
                                                        jQuery("#store2010-basket").html(data);
							jQuery("html, body").animate({ scrollTop: 0 }, "slow", "swing");
                                                }
                                        });
                                }
                        }
                });
        });

});
