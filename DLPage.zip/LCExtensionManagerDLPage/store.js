var gProductsRefresh;

jQuery(document).ready(function(){ 	
						   
	var path = "/wp-content/plugins/livecode_store/runrevstore/";
	
	jQuery.listen("click", ".s10_basket_qty_item_side", function(){ 				   
		var id = jQuery(this).attr("id"); 
		var quantity = jQuery(this).attr("quantity"); 
		var t = new  Date().getTime(); 
		jQuery.ajax({ 
			type: "GET", 
			url: path+"jquery-functions.php?f=basketQtyUpdate&t="+t, 
			data: "id="+id+"&quantity="+quantity, 
			success: function(data){ 
				//alert("Change Detected : Remove Product"); 
				var data_return = data.split("|"); 
				if(data_return[0].trim() == "1"){ 
					jQuery.ajax({ 
						type: "GET", 
						url: path+"jquery-functions.php?f=basketGenerateSide&t="+t, 
						success: function(data){ 
							//alert("Refreshing list"); 
							jQuery("#store2010-basket").html(data);
						}
					});
					if(gProductsRefresh) productsRefresh();
				}
			}
		});
	});
	
	// Arnaud - marketplace products listing filter handling
	jQuery(".filterlink").click(function() {
                var tabName = "filter_" + jQuery(this).text();
                jQuery('.filter_marketplace').fadeOut('250');
		jQuery('.filterlink').removeAttr("style");
		jQuery(this).css({ "background-color": "#666", "color":"#fff"});
                jQuery('.'+tabName+'').fadeIn('150');
		//jQuery('.'+tabName+'').animate({
	    	//opacity: .5,
	    	//width: 'linear',
	    	//height: '75%'
	   	//}, 8000, function() {
	   	//	console.log('animate() completed');
		//});
        });

	// AB - sidebar toggler
        jQuery('label.tree-toggler').click(function () {
                jQuery(this).parent().children('ul.tree').toggle(300);
        });
});
