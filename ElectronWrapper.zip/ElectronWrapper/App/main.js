// In the main process.
const { app, BrowserView, BrowserWindow } = require('electron')

let progressInterval

function createWindow () {
  const win = new BrowserWindow({
    width: 1000,
    height: 800
  })

  const INCREMENT = 0.03
  const INTERVAL_DELAY = 100 // ms

  let c = 0
  progressInterval = setInterval(() => {
    // update progress bar to next value
    // values between 0 and 1 will show progress, >1 will show indeterminate or stick at 100%
    win.setProgressBar(c)

    // increment or reset progress bar
    if (c < 2) {
      c += INCREMENT
    } else {
      c = (-INCREMENT * 5) // reset to a bit less than 0 to show reset state
    }
  }, INTERVAL_DELAY)
}

app.whenReady().then(() => {
  const win = new BrowserWindow( { width: 1024, height: 800, frame: true, webPreferences: {webSecurity: false} } )
  const view = new BrowserView()

  win.setBrowserView(view)
  view.setBounds({ x: 0, y: 0, width: 980, height: 780 })
  view.webContents.loadFile('index.html')
  //view.webContents.loadURL('https://openxtalk-org.github.io/OpenXTalk-Playground/')
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow()
  }
})
