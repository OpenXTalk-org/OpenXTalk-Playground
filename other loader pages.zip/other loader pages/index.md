<!doctype html>
<html lang="en-us">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Emscripten-Generated Code</title>
    <style>
      body {
        font-family: arial;
        margin: 0;
        padding: none;
      }

      .emscripten { padding-right: 0; margin-left: auto; margin-right: auto; display: block; }
      div.emscripten { text-align: center; }
      div.emscripten_border { border: 2px solid gray; }
      /* the canvas *must not* have any border or padding, or mouse coords will be wrong */
      canvas.emscripten { border: 0px none;
         cursor:url(http://www.javascriptkit.com/dhtmltutors/cursor-hand.gif) }

      #emscripten_logo {
        display: inline-block;
        margin: 0; }

      .spinner {
        height: 24px;
        width: 24px;
        margin: 10px;
        margin-top: 5px;
        margin-left: 5px;
        display: inline-block;
        vertical-align: top;

        -webkit-animation: rotation .5s linear infinite;
        -moz-animation: rotation .5s linear infinite;
        -o-animation: rotation .5s linear infinite;
        animation: rotation 0.5s linear infinite;

        border-left: 4px solid rgb(200, 200, 255);
        border-right: 4px solid rgb(170, 170, 200);
        border-bottom: 4px solid rgb(160, 160, 190);
        border-top: 4px solid rgb(150, 150, 180);

        border-radius: 32px;
        background-color: rgb(120, 120, 150);
      }

      @-webkit-keyframes rotation {
        from {-webkit-transform: rotate(0deg);}
        to {-webkit-transform: rotate(360deg);}
      }
      @-moz-keyframes rotation {
        from {-moz-transform: rotate(0deg);}
        to {-moz-transform: rotate(360deg);}
      }
      @-o-keyframes rotation {
        from {-o-transform: rotate(0deg);}
        to {-o-transform: rotate(360deg);}
      }
      @keyframes rotation {
        from {transform: rotate(0deg);}
        to {transform: rotate(360deg);}
      }

      #status {
        display: inline-block;
        vertical-align: top;
        margin-top: 30px;
        margin-left: 20px;
        font-weight: bold;
        color: rgb(120, 120, 120);
      }

      #progress {
        height: 100px;
        width: 100px;
      }

      #controls {
        display: inline-block;
        float: right;
        vertical-align: top;
        margin-top: 20px;
        margin-right: 20px;
      }

      #output {
        width: 100%;
        height: 200px;
        margin: 0 auto;
        margin-top: 10px;
        display: block;
        background-color: black;
        color: white;
        font-family: 'Lucida Console', Monaco, monospace;
        outline: none;
      }
    </style>
<script src="https://unpkg.com/hyperscript.org@0.9.7"></script>

  </head>
  <body>
    <a href="https://openxtalk.org">
      <?xml version="1.0" encoding="utf-8"?>
      <svg version="1.2" baseProfile="tiny" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
      x="0px" y="0px" width="48px" height="3%" viewBox="0 0 100 100" overflow="visible">
      <g>
      	<path fill="#666396" d="M155.99,57.5c2.72,2.56,1.73,6.05-1.1,8.12c1.73,1.8,1.48,4.46-0.07,6.22c1.63,1.66,1.78,4.3,0.26,6.03
      		c1.43,1.65,1.5,3.99,0.12,5.68c1.26,1.52,1.36,3.77,0.12,5.36c1.2,1.55,1.19,3.68,0,5.24c3.59,5.97-5.03,8.81-8.5,12.19
      		c-15.28,11.77-31.92,26.42-47.32,37.62c37.45,1.03,58.28-14.5,59.08-57.37c0.24-6.33,1.1-20.73-1.15-31.71
      		C157.13,55.29,156.38,57.14,155.99,57.5z"/>
      	<path fill="#666396" d="M43.27,79.51c-0.24-1.46,0.49-2.95,1.81-4.15c-3.99-3.59-0.67-7.76,2.53-9.69
      		c12.98-9.24,41.33-27.24,58.26-38.2c-33.74-1.7-63.94,10.6-64.68,53.38c-0.75,10.3-0.18,23.19,3.43,31.4
      		c-0.35-2.09-1.46-3.57,0.17-5.55c-1.29-1.62-1.08-3.79,0.1-5.37c-1.38-1.59-1.32-4.1,0.07-5.66c-1.59-1.68-1.3-4.46,0.21-6.06
      		c-1.77-1.91-1.77-4.6,0.08-6.46C44.02,82.11,43.38,80.82,43.27,79.51z"/>
      	<path fill="#666396" d="M62.11,137.03c7.16,4.68,18.53,5.27,23.13,5.96c-11.82-7.85-35.05-21.38-35.05-21.38
      		C49.77,121.82,53.68,131.52,62.11,137.03z"/>
      	<path fill="#666396" d="M149.41,44.65c1.81,1.16,3.52,2.31,5.05,3.4c-0.87-1.98-4.27-11.12-11.53-15.55
      		c-7.54-4.6-25.76-6.03-25.76-6.03C117.12,26.44,136.59,36.38,149.41,44.65z"/>
      	<path fill="#605A58" d="M150.86,100.05c2.45-1.76,2.97-2.75,2.97-3.26c-0.07-1.43-1.08-0.01-1.71,0.32
      		c-13.05,9.34-40.27,32.95-53.21,41.98c-2.5,1.29-5.24,3.37-7.9,1.74c-7.87-3.59-15.14-9.51-22.61-13.3
      		c-6.6-3.82-13.42-7.76-20.14-12.48c-0.7-0.31-1.84-1.98-1.94-0.48c0,0.52,0.56,1.54,3.23,3.41c14.2,9.29,27.64,17.14,42.22,25.5
      		c6.23,1.83,23.75-16.33,33.69-23.34C135.31,112.11,144.6,104.53,150.86,100.05z"/>
      	<path fill="#736F70" d="M49.54,112.72c14.2,9.29,27.64,17.14,42.22,25.5c6.23,1.83,23.76-16.34,33.7-23.34
      		c9.84-8.03,19.13-15.61,25.38-20.09c2.45-1.76,2.97-2.75,2.97-3.26c-0.07-1.4-1.08,0.04-1.71,0.36
      		c-13.05,9.34-40.27,32.96-53.21,41.98c-2.5,1.3-5.24,3.37-7.9,1.74c-7.87-3.58-15.14-9.51-22.61-13.3
      		c-6.6-3.82-13.42-7.76-20.14-12.48C45.4,107.2,45.51,110.15,49.54,112.72z"/>
      	<path fill="#6B6969" d="M49.53,107.5c14.2,9.28,27.64,17.15,42.22,25.5c6.23,1.83,23.76-16.33,33.7-23.34
      		c9.84-8.03,19.13-15.61,25.38-20.09c2.45-1.76,2.97-2.74,2.97-3.26c-0.05-1.54-1.08-0.38-1.69,0.04
      		c-13.05,9.34-40.27,32.95-53.21,41.98c-2.5,1.3-5.26,3.38-7.92,1.74c-7.87-3.58-15.14-9.52-22.61-13.3
      		c-6.6-3.82-13.42-7.76-20.14-12.48c-0.79-0.48-1.78-1.77-1.94-0.21C46.3,104.61,46.86,105.63,49.53,107.5z"/>
      	<path fill="#898E90" d="M49.51,101.96c14.2,9.29,27.64,17.15,42.22,25.5c6.23,1.82,23.75-16.33,33.69-23.34
      		c9.84-8.03,19.13-15.61,25.39-20.09c2.83-2.27,3.59-2.77,2.45-4.35c-13.65,9.75-40.86,33.38-54.41,42.89
      		c-2.5,1.29-5.24,3.38-7.89,1.75c-7.87-3.59-15.15-9.52-22.61-13.31c-6.6-3.82-13.42-7.76-20.14-12.48
      		c-0.91-0.64-1.7-1.61-1.94,0.02C46.28,99.06,46.84,100.08,49.51,101.96z"/>
      	<path fill="#969B9F" d="M49.49,96.21c14.2,9.3,27.66,17.14,42.22,25.5c6.23,1.83,23.75-16.33,33.7-23.34
      		c9.84-8.03,19.13-15.61,25.38-20.09c2.45-1.76,2.97-2.75,2.97-3.26c-0.08-0.96-0.88-1.8-1.71-0.77
      		c-13.04,9.34-40.26,32.97-53.21,42c-2.49,1.31-5.24,3.34-7.9,1.71c-7.87-3.59-15.14-9.51-22.61-13.31
      		c-6.6-3.81-13.42-7.76-20.14-12.48c-1.25-1.22-1.63-0.52-1.94,0.62C46.26,93.31,46.82,94.33,49.49,96.21z"/>
      	<path fill="#A7A8A7" d="M69.41,102.22c7.33,3.72,14.52,9.51,22.26,13.13c6.23,1.83,23.76-16.33,33.69-23.34
      		c9.84-8.03,19.13-15.61,25.39-20.09c3.04-2.47,3.78-2.86,2.09-4.76c-13.39,9.73-40.52,33.25-53.62,42.39
      		c-2.54,1.32-5.33,3.42-8.03,1.76c-8.02-3.65-15.42-9.7-23.04-13.56c-6.72-3.89-13.68-7.91-20.52-12.72
      		C39.8,86.47,67.65,100.82,69.41,102.22z"/>
      	<path fill="#ADB2B7" d="M47.66,77.46l-0.01-0.03c-0.18-0.12-0.34-0.23-0.52-0.35c-0.93,0.82-1.29,1.38-0.51,1
      		C47.39,77.27,47.53,77.36,47.66,77.46z"/>
      	<path fill="#ADB2B7" d="M48.92,82.67c14.48,9.47,28.2,17.49,43.04,26c6.36,1.87,24.28-16.71,34.45-23.88
      		c9.98-8.16,19.4-15.85,25.75-20.42c2.51-1.8,3.03-2.79,3.03-3.32c0-0.37-0.26-0.96-1.28-1.9c-13.39,9.56-41.14,33.66-54.4,42.91
      		c-2.55,1.33-5.36,3.43-8.08,1.76c-8.06-3.65-15.5-9.72-23.15-13.6c-6.59-3.81-13.41-7.76-20.61-12.78l-0.01,0.02l0,0
      		c-0.48,0.32-0.8,0.5-1.04,0.62c-0.25,0.27-0.58,0.63-0.99,1.12C45.63,79.73,46.21,80.76,48.92,82.67z"/>
      	<path fill="#D5D4D7" d="M95.11,37.64c-15.32,9.92-31.22,19.93-46.18,30.42c-0.92,0.73-1.61,1.29-2.15,1.78
      		c-0.15,0.15-0.34,0.32-0.46,0.46c-0.03,0.03-0.05,0.06-0.07,0.09c-0.21,0.26-0.19,2.13,0.03,2.4c0.01,0.01,0.02,0.02,0.03,0.03
      		c0.13,0.15,0.35,0.35,0.53,0.52c0.52,0.47,1.18,1.01,2.06,1.69c0.06,0.05,0.11,0.08,0.17,0.12c5.02,3.28,9.95,6.35,14.87,9.36
      		c6.13,3.63,12.07,6.99,18.22,10.86c3.77,1.86,7.38,4.95,11.42,6.14c3.97-0.88,7.15-4.08,11.45-6.86
      		c13.4-10.09,33.91-28.21,47.63-37.92c0.01-0.01,0.02-0.02,0.03-0.02c0.9-0.72,1.57-1.27,2.08-1.75c0.11-0.11,0.25-0.24,0.33-0.34
      		c0.04-0.04,0.06-0.08,0.1-0.12c0.26-0.33,0.38-0.58,0.45-0.81c0.1-0.25,0.09-0.44-0.02-0.71c-0.01-0.03-0.01-0.06-0.02-0.09
      		c-0.09-0.19-0.23-0.41-0.44-0.67c-0.02-0.02-0.03-0.04-0.05-0.06c-0.1-0.12-0.28-0.27-0.41-0.41c-0.51-0.47-1.17-1-2.06-1.7
      		c-12.11-8.65-20.54-13.11-35.89-20.53c-1.2-0.58-2.86-1.07-4.45-1.06c-1.96,0.08-3.74,0.71-5.49,1.61
      		c-1.92,1.24-3.97,2.56-6.13,3.96C98.97,35.27,97.15,36.52,95.11,37.64z"/>
      	<path fill="#1C1719" d="M46.62,78.08c0.24-0.12,0.56-0.3,1.04-0.62C47.53,77.36,47.39,77.27,46.62,78.08z"/>
      	<path fill="#1C1719" d="M102.75,22.4c-31.45,0.21-65.29,9.28-66.7,63.78c-1.06,21.33,4.31,37.45,11.1,46.96
      		c14.95,20.91,41.3,17,53.16,16.95c35.14-0.15,61.99-8.37,63.51-64.44C165.42,26.03,147.26,22.44,102.75,22.4z M142.93,32.51
      		c7.26,4.43,10.66,13.57,11.53,15.55c-10.26-7.58-37.76-21.92-37.3-21.58C117.17,26.48,135.39,27.9,142.93,32.51z M107.33,29.76
      		c2.46-1.58,6.9-1.76,9.42-0.22c21.52,10.74,35.89,20.53,35.89,20.53s1.55,1.23,2.06,1.7c0.13,0.13,0.31,0.29,0.41,0.41
      		c0.78,0.75,0.75,1.69-0.01,2.46c-0.08,0.1-0.23,0.23-0.33,0.34c-0.51,0.48-1.18,1.03-2.08,1.75
      		c-16.14,11.72-38.26,31.42-54.45,42.97c-1.46,0.73-3.07,1.86-4.66,1.83c-4.04-1.19-7.65-4.27-11.42-6.13
      		c-11.3-6.58-22.12-13.09-33.19-20.29c-0.87-0.68-1.61-1.27-2.13-1.75c-0.1-0.1-0.78-1.1-0.78-2c0-0.75,0.65-1.43,0.72-1.5
      		c0.54-0.49,1.24-1.07,2.16-1.79C67.9,54.81,88.02,42.32,107.33,29.76z M43.89,86.6c0.04,1.07,0.44,2.13,1.29,3.02
      		c-1.51,1.61-1.8,4.38-0.21,6.06c-1.39,1.55-1.45,4.07-0.07,5.66c-1.18,1.58-1.38,3.75-0.1,5.37c-1.63,1.98-0.53,3.46-0.17,5.55
      		c-3.61-8.22-4.17-21.09-3.43-31.4c0.65-42.65,31.11-55.25,64.68-53.38c-16.93,10.96-45.29,28.96-58.26,38.2
      		c-3.2,1.93-6.52,6.1-2.53,9.69c-2.62,2.3-2.36,5.6,0.19,7.79C44.32,84.16,43.74,85.37,43.89,86.6z M46.62,78.08
      		c-0.78,0.38-0.41-0.17,0.51-1c0.18,0.12,0.34,0.23,0.52,0.35c0.01,0,0.01,0.01,0.01,0.01c7.2,5.02,14.01,8.97,20.61,12.78
      		c7.65,3.89,15.09,9.95,23.15,13.6c2.72,1.67,5.53-0.43,8.08-1.76c13.26-9.24,41.01-33.35,54.4-42.91c1.02,0.93,1.28,1.53,1.28,1.9
      		c0,0.53-0.52,1.52-3.03,3.32c-6.35,4.57-15.77,12.26-25.75,20.42c-10.16,7.17-28.09,25.75-34.45,23.88
      		c-14.84-8.51-28.56-16.53-43.04-26c-2.72-1.91-3.29-2.94-3.29-3.48C46.05,78.71,46.37,78.34,46.62,78.08z M47.63,85.03
      		c6.84,4.81,13.8,8.83,20.52,12.72c7.62,3.86,15.03,9.91,23.04,13.56c2.7,1.65,5.49-0.44,8.03-1.76
      		c13.1-9.14,40.22-32.66,53.62-42.39c1.69,1.9,0.94,2.31-2.09,4.76c-6.26,4.48-15.55,12.06-25.39,20.09
      		c-9.94,7-27.47,25.17-33.69,23.34c-7.74-3.62-14.92-9.41-22.26-13.13C67.65,100.82,39.8,86.47,47.63,85.03z M48.2,92.17
      		c6.71,4.72,13.54,8.67,20.14,12.48c7.47,3.8,14.74,9.72,22.61,13.31c2.66,1.64,5.4-0.4,7.9-1.71c12.95-9.03,40.17-32.66,53.21-42
      		c0.83-1.03,1.64-0.19,1.71,0.77c0,0.52-0.52,1.5-2.97,3.26c-6.26,4.48-15.55,12.06-25.38,20.09c-9.94,7.01-27.47,25.17-33.7,23.34
      		c-14.56-8.36-28.02-16.2-42.22-25.5c-2.67-1.88-3.23-2.89-3.23-3.41C46.57,91.66,46.95,90.96,48.2,92.17z M48.22,98.52
      		c6.71,4.72,13.54,8.67,20.14,12.48c7.46,3.8,14.74,9.73,22.61,13.31c2.66,1.63,5.39-0.46,7.89-1.75
      		c13.55-9.51,40.75-33.13,54.41-42.89c1.14,1.57,0.38,2.08-2.45,4.35c-6.26,4.48-15.55,12.06-25.39,20.09
      		c-9.94,7.01-27.46,25.17-33.69,23.34c-14.58-8.36-28.02-16.22-42.22-25.5c-2.67-1.88-3.23-2.89-3.23-3.41
      		C46.52,96.91,47.31,97.87,48.22,98.52z M48.24,104.3c6.71,4.71,13.54,8.66,20.14,12.48c7.47,3.79,14.74,9.72,22.61,13.3
      		c2.66,1.63,5.42-0.45,7.92-1.74c12.94-9.03,40.16-32.64,53.21-41.98c0.61-0.43,1.64-1.59,1.69-0.04c0,0.52-0.52,1.5-2.97,3.26
      		c-6.26,4.48-15.55,12.06-25.38,20.09c-9.94,7.01-27.47,25.17-33.7,23.34c-14.58-8.36-28.02-16.22-42.22-25.5
      		c-2.67-1.88-3.23-2.89-3.23-3.41C46.45,102.52,47.45,103.81,48.24,104.3z M48.26,109.83c6.71,4.72,13.54,8.66,20.14,12.48
      		c7.47,3.79,14.74,9.72,22.61,13.3c2.66,1.63,5.4-0.44,7.9-1.74c12.94-9.03,40.16-32.64,53.21-41.98c0.63-0.31,1.64-1.76,1.71-0.36
      		c0,0.51-0.52,1.5-2.97,3.26c-6.26,4.48-15.55,12.06-25.38,20.09c-9.94,7-27.47,25.17-33.7,23.34
      		c-14.58-8.36-28.02-16.21-42.22-25.5C45.51,110.15,45.4,107.2,48.26,109.83z M62.11,137.03c-8.43-5.52-12.34-15.21-11.91-15.41
      		c0,0,23.23,13.52,35.05,21.38C80.65,142.3,69.27,141.72,62.11,137.03z M91.78,143.48c-14.58-8.36-28.02-16.21-42.22-25.5
      		c-2.67-1.88-3.23-2.89-3.23-3.41c0.1-1.5,1.24,0.17,1.94,0.48c6.71,4.72,13.54,8.67,20.14,12.48c7.47,3.79,14.74,9.72,22.61,13.3
      		c2.66,1.63,5.4-0.45,7.9-1.74c12.94-9.03,40.16-32.64,53.21-41.98c0.63-0.33,1.64-1.74,1.71-0.32c0,0.52-0.52,1.5-2.97,3.26
      		c-6.26,4.48-15.55,12.06-25.39,20.09C115.54,127.15,98.01,145.31,91.78,143.48z M158.58,86.6c-0.8,42.87-21.63,58.4-59.08,57.37
      		c15.41-11.2,32.04-25.85,47.32-37.62c3.48-3.38,12.08-6.22,8.5-12.19c1.19-1.56,1.19-3.68,0-5.24c1.24-1.6,1.14-3.84-0.12-5.36
      		c1.38-1.69,1.31-4.04-0.12-5.68c1.52-1.73,1.38-4.37-0.26-6.03c1.55-1.77,1.81-4.42,0.07-6.22c2.83-2.07,3.82-5.56,1.1-8.12
      		c0.39-0.36,1.14-2.21,1.45-2.61C159.68,65.87,158.83,80.27,158.58,86.6z"/>
      </g>
      </svg>
  </a>

    <div class="spinner" id='spinner'></div>
    <div class="emscripten" id="status">Downloading xTalk WebStack...</div>

<span id='controls'>
  <span><input type="checkbox" id="resize">Resize canvas</span>
  <span><input type="checkbox" id="pointerLock" checked>Lock/hide mouse pointer &nbsp;&nbsp;&nbsp;</span>
  <span><input type="button" value="Fullscreen" onclick="Module.requestFullScreen(document.getElementById('pointerLock').checked,
                                                                            document.getElementById('resize').checked)">
  </span>
</span>

    <div class="emscripten">
      <progress value="0" max="100" id="progress" hidden=1></progress>
    </div>


    <div class="emscripten_border">
      <div id="emscripten_main">
        <canvas class="emscripten" id="canvas" oncontextmenu="event.preventDefault()"></canvas>
      </div>
    </div>
    <textarea id="output" rows="8"></textarea>

    <script type='text/javascript'>
      var statusElement = document.getElementById('status');
      var progressElement = document.getElementById('progress');
      var spinnerElement = document.getElementById('spinner');

      var Module = {
        preRun: [],
        postRun: [],
        print: (function() {
          var element = document.getElementById('output');
          if (element) element.value = ''; // clear browser cache
          return function(text) {
            if (arguments.length > 1) text = Array.prototype.slice.call(arguments).join(' ');
            // These replacements are necessary if you render to raw HTML
            //text = text.replace(/&/g, "&amp;");
            //text = text.replace(/</g, "&lt;");
            //text = text.replace(/>/g, "&gt;");
            //text = text.replace('\n', '<br>', 'g');
            console.log(text);
            if (element) {
              element.value += text + "\n";
              element.scrollTop = element.scrollHeight; // focus on bottom
            }
          };
        })(),
        printErr: function(text) {
          if (arguments.length > 1) text = Array.prototype.slice.call(arguments).join(' ');
          if (0) { // XXX disabled for safety typeof dump == 'function') {
            dump(text + '\n'); // fast, straight to the real console
          } else {
            console.error(text);
          }
        },
        canvas: (function() {
          var canvas = document.getElementById('canvas');

          // As a default initial behavior, pop up an alert when webgl context is lost. To make your
          // application robust, you may want to override this behavior before shipping!
          // See http://www.khronos.org/registry/webgl/specs/latest/1.0/#5.15.2
          canvas.addEventListener("webglcontextlost", function(e) { alert('WebGL context lost. You will need to reload the page.'); e.preventDefault(); }, false);

          return canvas;
        })(),
        setStatus: function(text) {
          if (!Module.setStatus.last) Module.setStatus.last = { time: Date.now(), text: '' };
          if (text === Module.setStatus.text) return;
          var m = text.match(/([^(]+)\((\d+(\.\d+)?)\/(\d+)\)/);
          var now = Date.now();
          if (m && now - Date.now() < 30) return; // if this is a progress update, skip it if too soon
          if (m) {
            text = m[1];
            progressElement.value = parseInt(m[2])*100;
            progressElement.max = parseInt(m[4])*100;
            progressElement.hidden = false;
            spinnerElement.hidden = false;
          } else {
            progressElement.value = null;
            progressElement.max = null;
            progressElement.hidden = true;
            if (!text) spinnerElement.style.display = 'none';
          }
          statusElement.innerHTML = text;
        },
        totalDependencies: 0,
        monitorRunDependencies: function(left) {
          this.totalDependencies = Math.max(this.totalDependencies, left);
          Module.setStatus(left ? 'Preparing... (' + (this.totalDependencies-left) + '/' + this.totalDependencies + ')' : 'All downloads complete.');
        }
      };
      Module.setStatus('Downloading...');
      window.onerror = function(event) {
        // TODO: do not warn on ok events like simulating an infinite loop or exitStatus
        Module.setStatus('Exception thrown, see JavaScript console');
        spinnerElement.style.display = 'none';
        Module.setStatus = function(text) {
          if (text) Module.printErr('[post-exception status] ' + text);
        };
      };
    </script>

    <script>

          (function() {
            var memoryInitializer = 'standalone-community-9.6.3.html.mem';
            if (typeof Module['locateFile'] === 'function') {
              memoryInitializer = Module['locateFile'](memoryInitializer);
            } else if (Module['memoryInitializerPrefixURL']) {
              memoryInitializer = Module['memoryInitializerPrefixURL'] + memoryInitializer;
            }
            var xhr = Module['memoryInitializerRequest'] = new XMLHttpRequest();
            xhr.open('GET', memoryInitializer, true);
            xhr.responseType = 'arraybuffer';
            xhr.send(null);
          })();

          var script = document.createElement('script');
          script.src = "standalone-community-9.6.3.js";
          document.body.appendChild(script);

</script>
  </body>
</html>
